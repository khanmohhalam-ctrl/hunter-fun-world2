HUNTER FUN WORLD — TEST PROJECT v0.1

IMPORTANT:
- Yeh Android Studio source project ZIP hai, install hone wali APK nahi.
- APK banane ke liye computer/laptop par Android Studio aur Android SDK chahiye.
- Android Studio mein is folder ko Open karein, Gradle Sync complete hone dein,
  phir Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
- Is demo mein login/register sirf local validation dikhate hain.
  Online account, OTP, database, admin panel/backend abhi connected nahi hain.
- Password minimum 6 characters rakha gaya hai.
- Package: in.hunterfunworld.test
