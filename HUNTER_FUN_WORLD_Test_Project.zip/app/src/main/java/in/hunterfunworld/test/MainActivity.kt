package in.hunterfunworld.test

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(7, 13, 30))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        root.addView(label("HUNTER", 34f, Color.rgb(65, 170, 255)))
        root.addView(label("FUN WORLD", 24f, Color.rgb(255, 75, 75)))
        root.addView(label("TEST APP • VERSION 0.1", 12f, Color.LTGRAY))
        val name = EditText(this).apply { hint = "Username"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        val pass = EditText(this).apply { hint = "Password (minimum 6 characters)"; setSingleLine(); inputType = 129; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        root.addView(name)
        root.addView(pass)
        val login = Button(this).apply { text = "LOGIN" }
        root.addView(login)
        val register = Button(this).apply { text = "REGISTER" }
        root.addView(register)
        val sections = listOf("BGMI TOURNAMENTS", "GAMES", "DAILY QUIZ & CHALLENGES", "POINTS & LEADERBOARD", "COMMUNITY", "NOTIFICATIONS", "HELP & SUPPORT")
        sections.forEach { title ->
            val b = Button(this).apply { text = title; isAllCaps = false }
            root.addView(b)
            b.setOnClickListener { Toast.makeText(this, "$title — demo screen", Toast.LENGTH_SHORT).show() }
        }
        login.setOnClickListener {
            if (name.text.isBlank() || pass.text.length < 6) Toast.makeText(this, "Username aur kam se kam 6-character password daalein", Toast.LENGTH_LONG).show()
            else Toast.makeText(this, "Demo only: online login abhi connected nahi hai", Toast.LENGTH_LONG).show()
        }
        register.setOnClickListener {
            if (pass.text.length < 6) Toast.makeText(this, "Password kam se kam 6 characters ka hona chahiye", Toast.LENGTH_LONG).show()
            else Toast.makeText(this, "Demo only: registration abhi online connected nahi hai", Toast.LENGTH_LONG).show()
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
